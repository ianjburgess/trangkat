<div class="footer">
    <div class="text-center">© Copyright Trang Kat Photography 2017 | <a href="pages/terms&conditions.html">Terms & Conditions</a> | newborn photography melbourne</div>
</div>